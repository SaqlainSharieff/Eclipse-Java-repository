
public class Array1 {

	public static void main(String[] args) {
		int [] a1 = new int[5];
		a1[0]=1;
		a1[1]=2;
		a1[2]=3;
		a1[3]=4;
		a1[4]=5;
		System.out.println("The array are");
		System.out.println(a1[0]);
		System.out.println(a1[1]);
		System.out.println(a1[2]);
		System.out.println(a1[3]);
		System.out.println(a1[4]);
		
		

	}

}
