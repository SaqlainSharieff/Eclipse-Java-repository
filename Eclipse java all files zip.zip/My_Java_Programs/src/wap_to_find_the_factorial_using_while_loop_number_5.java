
public class wap_to_find_the_factorial_using_while_loop_number_5 {

	public static void main(String[] args) {
		int i = 1;
		int fact = 1;
		while (i <= 5) {
			fact = fact * i;
			i++;

		}
		System.out.println(fact);
	}
}
		
		
		

	


