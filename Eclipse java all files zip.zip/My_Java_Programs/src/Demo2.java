
public class Demo2 {

	public static void main(String[] args) {
		String str="fox";
		int i=0;
		while(i<str.length()) {
			System.out.print(str.charAt(i));
			i++;
		}

	}

}
