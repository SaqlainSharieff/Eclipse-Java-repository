
public class String1 {

	public static void main(String[] args) {
		String s = "Sharieff";
		int size = s.length();
		System.out.println("The size of the string is " + size);
		System.out.println("The characters are");
		for (int i = 0; i < s.length(); i++) {
			System.out.println(s.charAt(i));
		}

	}

}
