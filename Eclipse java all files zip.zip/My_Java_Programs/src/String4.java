
public class String4 {

	public static void main(String[] args) {
		String s = "Sharieff";
		char arr[] = s.toCharArray();
		System.out.println("The characters are");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}
