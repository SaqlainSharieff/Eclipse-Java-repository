
public class wap_to_print_5_to_negative_5_using_while {

	public static void main(String[] args) {
		int i=5;
		while(i>=-5)
		{
			System.out.println(i);
			i--;
		}

	}

}
