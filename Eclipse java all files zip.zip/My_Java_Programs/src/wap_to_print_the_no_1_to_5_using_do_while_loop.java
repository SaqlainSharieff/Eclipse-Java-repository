
public class wap_to_print_the_no_1_to_5_using_do_while_loop {

	public static void main(String[] args) {
		int i=1;
		do
		{
			System.out.println(i);
			i++;
		
		}
		while(i<=5);

	}

}
