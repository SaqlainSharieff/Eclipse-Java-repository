
public class Method2 {

	public static void main(String[] args) {
		add();
		System.out.println("Method not accepting parameter and not returning value");

	}

	public static void add() {
		int a = 2, b = 2;
		int sum = a + b;
		System.out.println(sum);
	}

}
