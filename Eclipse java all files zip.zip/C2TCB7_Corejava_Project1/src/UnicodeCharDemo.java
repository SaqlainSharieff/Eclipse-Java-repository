
public class UnicodeCharDemo {

	public static void main(String[] args) {
		char var1='\u00A8';
		System.out.println(var1);

	}

}
