
public class DesionMakingInOperators2 {

	public static void main(String[] args) {
		int x=8,y=7;
		if(x>=y)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
	}

}
