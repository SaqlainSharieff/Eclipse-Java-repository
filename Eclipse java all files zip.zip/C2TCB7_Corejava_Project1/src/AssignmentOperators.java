
public class AssignmentOperators {

	public static void main(String[] args) {
		int x=4;
		x+=5;
		System.out.println(x);
		x-=5;
		System.out.println(x);
		x*=5;
		System.out.println(x);
		x/=4;
		System.out.println(x);
		x%=5;
		System.out.println(x);

	}

}
