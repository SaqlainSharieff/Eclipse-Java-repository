
public class DesionMakingInOperators3 {

	public static void main(String[] args) {
		int x = 10;
		int y = 11;
		if (!(x < y) || (x == y)) {
			System.out.println("condition is true");
		} else {
			System.out.println("condition is false");
		}
	}

}
