
public class StringValueDemo {

	public static void main(String[] args) {
		String batchName = "C2TC-B7";
		String branch = new String("Bangalore");
		System.out.println(batchName);
		System.out.println(branch);

	}

}
