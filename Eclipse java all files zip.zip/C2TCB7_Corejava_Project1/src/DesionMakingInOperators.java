
public class DesionMakingInOperators {

	public static void main(String[] args) {
		int x=5;
		if(x!=5)
		{
			System.out.println("Value of x is not 5");
		}
		else
		{
			System.out.println("value of x is 5");
		}
	}

}
