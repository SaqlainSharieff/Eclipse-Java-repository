
public class IntDataTypeDemo {

	public static void main(String[] args) {
		byte maxbyte = 127;
		byte minbyte = -128;
		short maxshort = 32767;
		short minshort = -32768;
		int maxint = 2147483647;
		int minint = -2147483648;
		long maxlong = 9223372036854775807l;
		long minlong = -9223372036854775808l;

	}

}
