package basic;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Test1 {

	public static void main(String[] args) {
		FirefoxDriver d = new FirefoxDriver();

	}

}
