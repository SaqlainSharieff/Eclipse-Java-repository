package com.Capgemini.StringBuilderAssignments;

public class ReveseStringUsingStringBuilder {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("This method returns the reversed object on which it was called");
		System.out.println(sb.reverse());

	}

}
