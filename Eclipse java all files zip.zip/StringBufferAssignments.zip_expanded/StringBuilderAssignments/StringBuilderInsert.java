package com.Capgemini.StringBuilderAssignments;

public class StringBuilderInsert {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("It is used to _ at the specific index position");
		System.out.println(sb.replace(14, 15, "insert text"));

	}

}
