package com.Capgemini.StringClassAssignments;

public class StringLength {

	public static void main(String[] args) {
	String s1 = "Hello world";
	System.out.println(s1.length());

	}

}
