package com.stringBuffer.Assignments;

public class StringReverse {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("This method returns the reversed object on which it was called");
		System.out.println(sb.reverse());
	}

}
