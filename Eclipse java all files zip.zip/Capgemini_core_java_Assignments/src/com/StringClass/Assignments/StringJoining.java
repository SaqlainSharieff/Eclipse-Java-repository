package com.StringClass.Assignments;

public class StringJoining {

	public static void main(String[] args) {
		String s1 = "Hello ";
		String s2 = "How are you";
		System.out.println(s1.concat(s2));
	}

}
