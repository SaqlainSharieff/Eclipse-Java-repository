package com.oops.assignments;

public class Employee 
{
public void emp (){
	System.out.println("In the emp class");
}
}
