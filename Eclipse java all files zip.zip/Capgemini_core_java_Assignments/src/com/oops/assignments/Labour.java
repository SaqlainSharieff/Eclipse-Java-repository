package com.oops.assignments;

public class Labour extends Employee
{
	int overtime;
public void emp() 
{
	System.out.println("In the labour class which extends employee class");
}
}
