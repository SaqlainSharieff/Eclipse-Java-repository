package com.oops.assignments;

final class SingleTon {

	public static void main(String[] args) {
		System.out.println("Its a final class cant be inherited");

	}

}
