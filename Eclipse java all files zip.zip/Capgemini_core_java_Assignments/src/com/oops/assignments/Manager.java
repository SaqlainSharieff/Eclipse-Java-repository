package com.oops.assignments;

public class Manager extends Employee

{
	int incentive;
	
 public void mgr() 
 {
	 System.out.println("In the manager class which extends Employee class");
 }
}
